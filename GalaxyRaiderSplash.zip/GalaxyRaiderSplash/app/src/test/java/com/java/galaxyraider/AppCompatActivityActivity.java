package com.java.galaxyraider;

public class AppCompatActivityActivity {
}
